#ifndef __NETCFG_API__H__
#define  __NETCFG_API__H__

int user_netcfg_cfg(IN CONST CHAR_T *ssid,IN CONST CHAR_T *passwd,IN CONST CHAR_T *token);
int user_netcfg_init();


#endif
