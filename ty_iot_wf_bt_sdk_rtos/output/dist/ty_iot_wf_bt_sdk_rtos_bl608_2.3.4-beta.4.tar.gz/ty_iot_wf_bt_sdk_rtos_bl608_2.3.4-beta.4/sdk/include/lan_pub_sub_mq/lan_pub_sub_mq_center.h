#ifndef __LAN_PUB_SUB_MQ_CENTER_H
#define __LAN_PUB_SUB_MQ_CENTER_H

#include "tuya_cloud_com_defs.h"

#ifdef __cplusplus
	extern "C" {
#endif


/***********************************************************
*************************micro define***********************
***********************************************************/


OPERATE_RET lan_pub_sub_mq_center_init();


#ifdef __cplusplus
}
#endif
#endif

