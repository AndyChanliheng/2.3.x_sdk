#ifndef __PEGASUS_NETCFG__
#define __PEGASUS_NETCFG__

int pegasus_netcfg_init();

#endif
