#ifndef __LIHGT_PRINT_H__
#define __LIHGT_PRINT_H__

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#include "uni_log.h"




#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __LIHGT_PRINT_H__*/ 

